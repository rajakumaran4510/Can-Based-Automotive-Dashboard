
#include "sensor.h"
#include "adc.h"
#include "can.h"
#include "msg.h"

char str_rpm[5];

uint16_t get_rpm()
{
    // Step 1: Read ADC and convert to speed
    unsigned short int speed;
    speed = (unsigned short)(read_adc(CHANNEL4) / 10.23);

    // Step 2: Calculate RPM
    unsigned int rpm = speed * 60;

    // Step 3: Convert RPM to ASCII string (max 4 digits)
    str_rpm[0] = ((rpm / 1000)%10) + '0';            // Thousands
    str_rpm[1] = ((rpm / 100) % 10) + '0';      // Hundreds
    str_rpm[2] = ((rpm / 10) % 10) + '0';       // Tens
    str_rpm[3] = (rpm % 10) + '0';              // Ones
    str_rpm[4] = '\0';                          // Null terminator

    // Step 4: Send over UART
//    puts("RPM: ");
//    puts(rpm_str);
//    puts("\n\r");
    return rpm;
}

/*uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}*/
unsigned pre_key = 0x0F;
IndicatorStatus process_indicator()
{
    //Implement the indicator function
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    if (key != 0x0f)
    {
        pre_key = key;
    }

    if (pre_key == SWITCH1)  // Left indicator
    {
        return e_ind_left;
    }
    else if (pre_key == SWITCH3)  // Right indicator
    {
        return e_ind_right;
    }
    else if (pre_key == SWITCH2)  // Turn off all indicators
    {
        return e_ind_off;
    }
    else if (pre_key == SWITCH4)  // hazards light signals
    {
        return e_ind_hazard;
    }
}