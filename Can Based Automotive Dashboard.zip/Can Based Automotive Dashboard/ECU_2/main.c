#include <xc.h>
#define _XTAL_FREQ 20000000
#include "adc.h"
#include "sensor.h"
#include "msg.h"

void init_config() {
    TRISB = 0x00;
    PORTB = 0x00;
    init_adc();
    init_digital_keypad();
    init_can();
}

void main(void) {

    init_config();
    while (1) {
        unsigned int rpm = get_rpm();
         can_transmit(RPM_MSG_ID, str_rpm, 4);  // Transmit RPM over CAN (4-byte string)
        __delay_ms(100);                // Delay for stability
        
        unsigned int key = process_indicator(); //Variable to store which button is pressed
        static int flag; //It stores the current state of indicators
        static unsigned char toggle = 0; //Used for blinking effect
        toggle = !toggle;
        if(key == LEFT_IND_ON)
        {
            flag = 1;
        }
        else if(key == RIGHT_IND_ON)
        {
            flag = 2;
        }
        else if(key == HAZARD_OFF)
        {
            flag = 0;
        }
        else if(key == HAZARD_ON)
        {
            flag = 3;
        }
        if(flag == 1)
        {
            if (toggle)
            LEFT_IND_ON;
            else
            LEFT_IND_OFF;

            RIGHT_IND_OFF;
        }
        else if(flag == 2)
        {
             if (toggle)
            RIGHT_IND_ON;
            else
            RIGHT_IND_OFF;

            LEFT_IND_OFF;
        }
        if(flag == 0)
        {
            LEFT_IND_OFF;                      
            RIGHT_IND_OFF;
        }
        else if (flag == 3)
        {
            if (toggle)
            {
                LEFT_IND_ON;
                RIGHT_IND_ON;
            }
            else
            {
                LEFT_IND_OFF;
                RIGHT_IND_OFF;
            }
        }
        can_transmit(INDICATOR_MSG_ID, &flag, 1);  // Transmit indicator status over CAN
        __delay_ms(100);                            // Delay before next iteration
    }
}