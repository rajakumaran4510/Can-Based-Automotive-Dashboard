#include <xc.h>
#include "msg.h"
#include "clcd.h"

static void init_leds() 
{
    TRISB = 0x00;                        // Set RB3 as input, rest of PORTB as output
    PORTB = 0x00;                        // Clear PORTB initially
}

void init_config()
{
    init_clcd();
    init_leds();
    init_can();
    clcd_print("spd gear rpm ind", LINE1(0));  // Display headers on line 1 of CLCD
}

void main(void) {
    
    init_config();                       

    while (1) 
    {
        process_canbus_data();          // Continuously receive and process CAN data
    }
    return;
}
